# rangeModelMetadata
rangeModelMetadata provides convenient access to creating metadata objects associated with species range models in R.

This is the development version of the package; stable versions are hosted on CRAN. 

To install type: 

__devtools::install_github('cmerow/rangeModelMetaData')__

You may need to install the devtools package first with install.packages('devtools').
